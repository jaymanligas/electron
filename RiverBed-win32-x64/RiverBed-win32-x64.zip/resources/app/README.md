# Riverbed registration

##clone and install

git clone https://github.com/jaymanligas/electron.git

npm install
